import { ethers } from "ethers";

export const provider = new ethers.JsonRpcProvider(
  "https://rpc-amoy.polygon.technology"
);