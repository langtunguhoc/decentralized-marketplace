import { LitNodeClient } from "@lit-protocol/lit-node-client";
import { encryptFile as litEncryptFile } from "@lit-protocol/encryption";
import { LIT_ABILITY } from "@lit-protocol/constants";
import {
  LitAccessControlConditionResource,
} from "@lit-protocol/auth-helpers";
import { checkAndSignAuthMessage } from "@lit-protocol/auth-browser";

// 1. Initialize Client (Singleton)
const client = new LitNodeClient({
  litNetwork: "datil-dev", 
  debug: false,
});

// 2. Connection Helper
const connectLit = async () => {
  if (!client.ready) {
    try {
      await client.connect();
      console.log("🔥 Lit Protocol Connected");
    } catch (error) {
      console.error("Lit connection error:", error);
    }
  }
};

const getAccessConditions = (chain: string, contractAddress: string, productId: number) => {
  return [
    {
      conditionType: "evmContract",
      contractAddress: contractAddress,
      chain: chain,
      functionName: "hasAccess",
      functionParams: [":userAddress", productId.toString()],
      functionAbi: {
        name: "hasAccess",
        inputs: [
          { name: "user", type: "address" },
          { name: "productId", type: "uint256" }
        ],
        outputs: [{ name: "", type: "bool" }],
        stateMutability: "view",
        type: "function"
      },
      returnValueTest: {
        key: "",
        comparator: "=",
        value: "true",
      },
    },
  ];
};

export const encryptFile = async (
  file: File, 
  chain: string, 
  accessPassAddress: string, 
  productId: number
) => {
  await connectLit();

  const unifiedAccessControlConditions = getAccessConditions(chain, accessPassAddress, productId);

  const sessionSigs = await client.getSessionSigs({
    chain,
    resourceAbilityRequests: [
      {
        // Fix 1: Cast to 'any' to resolve strict type mismatch
        resource: new LitAccessControlConditionResource('*') as any,
        ability: LIT_ABILITY.AccessControlConditionDecryption,
      },
    ],
    authNeededCallback: async (params) => {
        const authSig = await checkAndSignAuthMessage({
            chain,
            expiration: params.expiration,
            uri: params.uri,
            resourceAbilityRequests: params.resourceAbilityRequests,
            nonce: params.nonce, // Fix 2: Added missing 'nonce'
        });
        return authSig;
    },
  });

  const { ciphertext, dataToEncryptHash } = await litEncryptFile(
    {
      file,
      unifiedAccessControlConditions,
      chain,
      sessionSigs,
    },
    client
  );

  return {
    encryptedFileBlob: ciphertext,
    encryptedKey: dataToEncryptHash,
  };
};